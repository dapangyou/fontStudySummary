cookie session sessionStorage localStorage
cookie: 客户端会话技术 可持久化到硬盘
session: 服务端会话技术  
sessionStorage: 浏览器关闭就会消失 只要是在同一个界面 刷新也不会影响 sessionStorage
localStorage： 存储在本地 可永久保存
